/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */
package com.mycompany.panaderia;

/**
 *
 * @author ferna
 */
public class Panaderia {

    public static void main(String[] args) {
        DatabaseManager databaseManager = new DatabaseManager();

        Controller controller = new Controller(databaseManager);
        controller.mostrarFuncionarios();
    }
}
