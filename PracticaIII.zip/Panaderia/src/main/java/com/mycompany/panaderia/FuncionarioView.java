/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.panaderia;

import javax.swing.*;
import java.awt.*;
import java.util.List;

/**
 *
 * @author ferna
 */
public class FuncionarioView extends JFrame {

    private JList<String> funcionariosList;

    public FuncionarioView(List<Funcionario> funcionarios) {
        setTitle("Funcionarios");
        setSize(300, 200);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLayout(new BorderLayout());

        DefaultListModel<String> model = new DefaultListModel<>();
        for (Funcionario funcionario : funcionarios) {
            model.addElement(funcionario.getNombre());
        }
        funcionariosList = new JList<>(model);
        add(new JScrollPane(funcionariosList), BorderLayout.CENTER);
    }
}
