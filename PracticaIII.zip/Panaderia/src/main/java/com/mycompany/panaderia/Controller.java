/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.panaderia;

/**
 *
 * @author ferna
 */
public class Controller {

    private DatabaseManager databaseManager;

    public Controller(DatabaseManager databaseManager) {
        this.databaseManager = databaseManager;
    }

    public void mostrarFuncionarios() {
        List<Funcionario> funcionarios = databaseManager.getFuncionarios();
        FuncionarioView funcionarioView = new FuncionarioView(funcionarios);
        funcionarioView.setVisible(true);
    }

    public void mostrarProductos() {
        List<Producto> productos = databaseManager.getProductos();
        // Implementa la vista para mostrar los productos
    }

    public void realizarCompra(Compra compra) {
        databaseManager.insertarCompra(compra);
        // Actualizar la vista del historial de compras
    }

    public void mostrarHistorialCompras() {
        List<Compra> compras = databaseManager.getHistorialCompras();
        // Implementa la vista para mostrar el historial de compras
    }
}
