/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.panaderia;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author ferna
 */
public class DatabaseManager {

    private static final String URL = "jdbc:mysql://localhost:3306/panaderia";
    private static final String USER = "root";
    private static final String PASSWORD = "Fdcc_08@****";

    public List<Funcionario> getFuncionarios() {
        List<Funcionario> funcionarios = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD); Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery("SELECT * FROM Funcionario")) {
            while (resultSet.next()) {
                Funcionario funcionario = new Funcionario(resultSet.getInt("id"),
                        resultSet.getString("nombre"),
                        resultSet.getString("username"),
                        resultSet.getString("password"));
                funcionarios.add(funcionario);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return funcionarios;
    }

    public List<Producto> getProductos() {
        List<Producto> productos = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD); Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery("SELECT * FROM Producto")) {
            while (resultSet.next()) {
                Producto producto = new Producto(resultSet.getInt("id"),
                        resultSet.getString("nombre"),
                        resultSet.getDouble("precio"));
                productos.add(producto);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return productos;
    }

    public void insertarCompra(Compra compra) {
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD); PreparedStatement statement = connection.prepareStatement("INSERT INTO Compra (fecha, hora, total) VALUES (?, ?, ?)")) {
            statement.setDate(1, compra.getFecha());
            statement.setTime(2, compra.getHora());
            statement.setDouble(3, compra.getTotal());
            statement.executeUpdate();
        } catch (SQLException e) {
            e.printStackTrace();
        }
    }

    public List<Compra> getHistorialCompras() {
        List<Compra> compras = new ArrayList<>();
        try (Connection connection = DriverManager.getConnection(URL, USER, PASSWORD); Statement statement = connection.createStatement(); ResultSet resultSet = statement.executeQuery("SELECT * FROM Compra")) {
            while (resultSet.next()) {
                Compra compra = new Compra(resultSet.getInt("id"),
                        resultSet.getDate("fecha"),
                        resultSet.getTime("hora"),
                        resultSet.getDouble("total"));
                compras.add(compra);
            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return compras;
    }
}
